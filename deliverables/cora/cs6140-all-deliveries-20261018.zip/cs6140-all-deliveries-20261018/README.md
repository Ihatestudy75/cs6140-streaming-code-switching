# CS6140 Baseline

Read [REPORT.md](REPORT.md).

Run: `python3 run.py --out runs/reproduction`. Use an empty output folder.
