# 方法与决策说明：阿拉伯语、印地语、中文、日语、西班牙语、越南语 × 英语

作者：yulun。适用于 `ar_en`、`hi_en`、`zh_en`、`ja_en`、`es_en`、`vi_en` 六组。

这里说明每个处理决定的依据、在数据中发现的问题，以及给团队的建议（第 6 节）。共用代码 `update1_data_standard/` 未作任何修改，与 `main` 提交 `367d6ec` 相同。

> 当前进度：6 组都已完成，通过 `pipeline.py validate`，6 组一起 `split` 没有报错，也和 shaoyu 的 `ko_en` 一起测试过。每组 20 条 record 已核查（模型辅助），见第 3.5 节。

## 1. 团队统一设置

| 项目 | 设置 |
|---|---|
| 代码 | `update1_data_standard/` 原样，提交 `367d6ec` |
| Tokenizer | mBERT `google-bert/bert-base-multilingual-cased`，revision `3f076fdb1ab68d5b2880cb87a0886f315b8146f8`，tokenizer_sha256 `78b44c32238e3b5e83d1deaa63c3fa1466ddf73547ce641a36f75180079ab45f` |
| 序列 | 逐条目处理：每个提取条目一个序列，不拼接 |
| 标签规则 | `--neutral-policy inherit_previous`，`--end-policy observed` |
| 未核查数据 | `--allow-unreviewed` |
| 抽样 | 每组 500 条原始 record，`random.Random(f'6140:{pair}').sample(range(1, total+1), 500)`，和 shaoyu 相同（`scripts/sample_records.py`） |

**Tokenizer 的来源：** 在 Windows 上运行 `prepare-tokenizer`（固定 revision），得到 `28108c3b…`。差别只在 `special_tokens_map.json` 和 `tokenizer_config.json` 的 CRLF 换行（`vocab.txt`、`tokenizer.json` 本来就是 LF）。转成 LF 后，`tree_hash` 为 `78b44c32…`，和团队的值一致。另外用这份 tokenizer 重新 tokenize shaoyu 交付的 `ko_en`（1,529 个序列）和 `yue_en`（2,560 个序列），结果和他的 `labeled_tokens_shaoyu.jsonl` 逐行完全相同。

## 2. 语言代码的选择

`ar`、`hi`、`zh`、`ja`、`es`、`vi`、`en`。

**中文用 `zh`，不用 `cmn`。** 理由：

- 原始 CSV 的 `first_language` 一栏 8,458 条全部是 `Chinese`，不是 Mandarin。SwitchLingua 把 Chinese 和 Cantonese 分成两种语言，Cantonese 由 shaoyu 用 `yue` 处理。
- 内容是书面中文，不全是普通话：约 7.9% 的 record 以繁体字为主，约 1.2% 含粤语字（例如 `嘅`、`係`、`唔`）。`cmn` 专指普通话，对这些 record 反而不准确。
- 团队其他代码有两字母代码的都用两字母（`ko`、`ru`、`ms`、`fr`、`de`、`it`）。`yue` 用三字母是因为它没有两字母代码。

报告中要说明：按 ISO 标准 `zh` 是包含 `yue` 的宏语言。本项目中 `zh` 指 SwitchLingua 的 Chinese 文件，`yue` 指 Cantonese 文件，两者是不同的数据文件。

## 3. 标注方法

### 3.1 三种做法

| 语言对 | 方法 | 脚本 | 理由 |
|---|---|---|---|
| ar_en、zh_en、ja_en | Unicode 文字系统规则 | `lid_script.py` | 两种语言文字不同，按文字判断几乎是确定的 |
| es_en、vi_en | Claude 逐词标注 | `lid_claude.py` | 两种语言都是拉丁字母，文字规则无法区分 |
| hi_en | 混合：天城文用文字规则，拉丁字母词由 Claude 标注 | `lid_claude.py --script-native` | 印地语有一半以上用拉丁字母书写（见 3.4） |

### 3.2 文字系统规则（ar、zh、ja，以及 hi 的天城文部分）

`scripts/lid_script.py` 是 shaoyu 的 `lid_script.py` 的扩展版。`char_label()`、`segments_for()`、`main()`、空白继承、NEUTRAL 处理、manifest 和 `validate_lid()` 调用**和 shaoyu 的完全相同**，只增加了文字范围常数：

| 语言 | 母语文字 |
|---|---|
| `ar` | 阿拉伯字母（基本区、补充区、扩展 A、表现形式 A/B） |
| `hi` | 天城文（基本区、扩展区） |
| `zh` | 汉字（和 shaoyu 的 `yue` 相同） |
| `ja` | 平假名、片假名、半角片假名、汉字，以及 `々` `〆` |

和 shaoyu 相同的约定：拉丁字母（包括专有名词）标 `en`；数字、标点、符号标 `NEUTRAL`；其他文字标 `UNKNOWN`；空白跟随前一个字符。`HAN`、`HANGUL`、`CYRILLIC` 没有改动，所以用这个脚本跑 `yue`、`ko`、`ru` 会得到和 shaoyu 完全相同的标签。`VERSION` 保持 `v1.0`；两份脚本可以用 `lid_manifest` 中的 `script_sha256` 区分。

**母语区块内的标点和数字标为 NEUTRAL。** 阿拉伯文和天城文的 Unicode 区块里包含标点和数字。如果直接用整个区块，`you know؟` 中的 `؟` 会被标为 `ar`，在 `know` 和 `؟` 之间产生一个长度为 1 的假切换。在完整 CSV 中统计（前一个非空白字符是拉丁字母）：

| 字符 | 总次数 | 紧跟英语 |
|---|---:|---:|
| `،` 阿拉伯逗号 | 14,889 | 754 |
| `؟` 阿拉伯问号 | 1,236 | 886 |
| `؛` 阿拉伯分号 | 7 | 2 |
| `।` 天城文句号 | 5,886 | 245 |
| `・` 片假名中点 | 729 | 13 |

用整个区块会产生约 1,900 个假切换。所以范围常数排除了这些字符，让 `char_label()` 按 Unicode 类别把它们标为 `NEUTRAL`，和 shaoyu 处理中文、韩文标点的结果一致：

- 阿拉伯：`،` `؛` `؟` `۔`，阿拉伯–印度数字及分隔符（U+0660–066D），扩展阿拉伯–印度数字（U+06F0–06F9）
- 天城文：`।` `॥`，天城文数字，缩写符号（U+0964–0970）
- 日语：`・`

**`々` 和 `〆` 标为 `ja`。** `々`（`人々`、`時々`）的 Unicode 类别是字母，但不在假名、汉字区块内，按原规则会标为 `UNKNOWN`。日语文件中出现 436 次，所以加入 `ja` 的范围。HAN 范围没有改动。

### 3.3 Claude 逐词标注（es、vi，以及 hi 的拉丁字母词）

**为什么不用 Lingua。** 先用 Lingua 2.2.0（yufan 的工具，转换规则和他的 `annotate_lingua.py` 相同，脚本见 `scripts/lid_lingua.py`）试跑 es_en 的 20 条 pilot record（64 个条目）：约 30 个条目（47%）有错，约 45 个词。错误几乎都在切换点：句尾的 `right?`、`you know?`、`anyway` 被并入前面的西班牙语，`¿verdad?`、`¿no?` 被并入前面的英语，`y` 被标为英语。SwitchLingua 约三分之一是 Tag switching，正好是 Lingua 最弱的地方。同样 64 个条目由 Claude 标注，这些错误全部正确。

**流程（`scripts/lid_claude.py`）：**

1. `prepare`：把每个条目切成"词"（字母组成，可含词内撇号和连字符），写成批次文件，每批 100 个条目。
2. 标注：每个词只回传一个代码（`n` 母语、`e` 英语、`u` UNKNOWN），不重写原文。标注规则见 `scripts/lid_claude_instructions.md`，是共用 `LID_PROMPT.md` v1.0 的逐词版本。每组 16 批，由 8 个 Claude 子代理并行完成。
3. `assemble`：程序按原文位置组回 segments。空白、标点、数字标 `NEUTRAL`（和 Lingua 转换规则相同）。代码数和词数不一致的条目直接报错，不做字符串修补。所以 segments 一定逐字还原原文。
4. 统一（`scripts/lid_claude_harmonize.py`）：不同子代理对专有名词和借词的处理不一致（例如 `fans` 在 es_en 中有 21 次标 `en`、8 次标 `es`；有的批次把所有人名标 `UNKNOWN`，有的把英语人名标 `en`）。所以把所有专有名词、借词、`UNKNOWN` 词和插入词收集起来，交给一个子代理按同一规则重新判断。三组都附上了前一组的决定表，保证跨语言对一致。改动记录在 `harmonize_changes_yulun.jsonl`。

| 语言对 | 统一的候选词 | 改动 |
|---|---:|---:|
| es_en | 1,922 | 123 |
| vi_en | 2,519 | 75 |
| hi_en | 2,604 | 70 |

**专有名词和借词的规则**（`lid_claude_instructions.md` 第 4、5 条）：

- 名字按书写形式判断，不按句子语言，也不按人的国籍：英语词或英语形式 → `en`（`Taylor Swift`、`Washington State`、`NASA`）；母语形式 → 母语（`Estados Unidos`、`Hoa Kỳ`、`Narendra Modi`）；两种语言拼法相同或来自第三种语言 → `UNKNOWN`（`Musk`、`Trump`、`Sony`、`Texas`、`China`）。
- 借词：保持英语原形的英语词 → `en`（`fans`、`show`、`game`）；已是母语一般用字或母语拼写 → 母语（`golf`、`tivi`、`crore`、`yoga`）；两种语言拼法相同的普通词跟随所在子句。

**自动检查：**

- 每批的 ID 顺序与输入一致。
- es：西班牙语附加语（`¿verdad?`、`¿no?`）标为 `en`、英语附加语（`you know`、`right`）在句尾标为 `es`：发现 2 处错误（`en Saturday Night Live` 的 `en`、`to see quién domina` 的 `quién`），已在统一步骤修正。
- vi：带越南语声调的词标为 `en` 或 `UNKNOWN`：发现 1 处（`Chủ nhật` 的 `nhật`），已修正；常见英语词标为 `vi`：0 处。越南语声调很密，错位一格几乎一定会被这项检查发现。
- hi：常见印地语功能词（`hai`、`ki`、`mein` 等）标为 `en`：0 处真错误；英语段落中的英语词标为 `hi`：0 处。
- 子代理在写出前也逐词检查过错位，共自行发现并修正了十几个错位一格的条目。

**成本：** 使用 Claude Code 订阅额度，没有另外的 API 费用。每组的标注加统一约 140 万 token。

### 3.4 印地语的两种书写方式

印地语文件中大量印地语用拉丁字母书写，例如 `Ye news sun kar log bahut chintit ho gaye hain, especially those who depend on federal jobs.` 全部 8,381 条 record 中只有 40.6% 含天城文字母；两种写法很少在同一条 record 中混用。

文字规则会把拉丁字母印地语全部标为 `en`。第一版交付（git 历史中的 `687072f`）因此只从含天城文的 record 中抽样。这会丢掉 59.4% 的数据，而且只代表一种书写方式，所以现在改为：

- 和其他组一样，从全部 record 中抽 500 条（`sample_records.py`）。
- `lid_claude.py --script-native`：天城文字符用 `lid_script.py` 的文字规则标注（和第一版完全相同）；只有全部由拉丁字母组成的词交给 Claude 判断。
- 同一批 500 条 record，纯文字规则标出约 3 万个印地语字符、11.8 万个英语字符；现在是 6.1 万个印地语字符、7.7 万个英语字符。

印地语和英语同形的词按上下文判断：`main`（मैं）、`the`（थे）、`is`/`us`（इस/उस）、`hi`（ही）、`to`（तो）、`par`、`do`（दो）。

### 3.5 抽样核查（pilot review）

做法和 shaoyu 相同：

- 每组随机选 20 条 record：`random.Random(f'6140:{pair}:pilot').sample(sorted(抽中的 record_id), 20)`。这条规则能完全重现 shaoyu 的 3 组 pilot record。这些 record 的所有条目标为 `reviewed`。
- record ID 在 `<pair>/annotation/pilot_record_ids_yulun.txt`。划分时用 `--train-records` 固定进 train。
- 逐条检查每个条目的所有片段：切换边界、附加语、同形词、标点和数字、专有名词。
- 修正用 `scripts/build_item_lid.py`（改自 shaoyu 的同名脚本，逻辑和输出格式相同），记录在 `review_yulun.csv` 和 `build_manifest_yulun.json`。

| 语言对 | 核查条目 | 修正 |
|---|---:|---:|
| ar_en | 72 | 0 |
| hi_en | 70 | 0 |
| zh_en | 81 | 0 |
| ja_en | 68 | 0 |
| es_en | 64 | 0 |
| vi_en | 61 | 0 |

- **核查是模型辅助的。** 由 Claude 完成，我委托。`review_yulun.csv` 的 reviewer 一栏写明了这一点。es、vi、hi 的标注本身也是 Claude 做的，所以这些组的核查**不是独立的**：同一类模型的错误可能在核查中重复出现。报告中不能称为人工核查。
- 其余条目都是 `unreviewed`，是伪标签。

## 4. 数据统计

| 语言对 | 方法 | record | 序列 | 有效位置 | 切换 | 切换率 | Small / Medium / Large | Large 占比 | 切换但 duration 无效 | UNKNOWN subword |
|---|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| ar_en | 文字规则 | 500 | 1,594 | 40,784 | 1,936 | 4.7% | 351 / 605 / 935 | 49% | 45 | 64 |
| zh_en | 文字规则 | 500 | 1,747 | 54,032 | 2,402 | 4.4% | 379 / 668 / 1,283 | 55% | 72 | 163 |
| ja_en | 文字规则 | 500 | 1,662 | 52,918 | 2,300 | 4.3% | 374 / 567 / 1,254 | 57% | 105 | 194 |
| hi_en | 混合 | 500 | 1,571 | 42,575 | 6,198 | 14.6% | 2,661 / 2,031 / 1,325 | 22% | 181 | 676 |
| es_en | Claude | 500 | 1,561 | 37,355 | 2,319 | 6.2% | 417 / 748 / 1,016 | 47% | 138 | 642 |
| vi_en | Claude | 500 | 1,595 | 39,495 | 2,701 | 6.8% | 640 / 935 / 932 | 37% | 194 | 819 |

抽中的 500 条 record 都有条目，抽样范围内没有 extraction error（hi_en 有 3 个、zh_en 有 1 个 `possible_wrapping_or_escape` warning，按共用规则只记录，没有修改原文）。

按切换类型的序列数（按原始 record 的 cs_type）：

| 语言对 | Intersentential | Intrasentential | Extra-sentential / Tag |
|---|---:|---:|---:|
| ar_en | 431 | 531 | 632 |
| zh_en | 554 | 473 | 720 |
| ja_en | 492 | 551 | 619 |
| hi_en | 519 | 489 | 563 |
| es_en | 453 | 488 | 620 |
| vi_en | 418 | 452 | 725 |

只有一种语言的序列：ar_en 250，zh_en 106，ja_en 69，hi_en 49，es_en 46，vi_en 65。抽查后确认是对话中独立的单语句子。

**UNKNOWN subword 的来源：**

| 语言对 | `[UNK]` token | 字符标为 UNKNOWN | UNKNOWN 后的标点 |
|---|---:|---:|---:|
| ar_en | 64 | 0 | 0 |
| zh_en | 137 | 0 | 26 |
| ja_en | 141 | 0 | 53 |
| hi_en | 90 | 497 | 89 |
| es_en | 76 | 455 | 111 |
| vi_en | 89 | 633 | 97 |

hi、es、vi 的"字符标为 UNKNOWN"几乎全是第 3.3 节规则下的专有名词（`Trump`、`Musk`、`Google`、`Samsung`…）。文字规则的组把拉丁字母名字一律标 `en`，所以没有这一项。

## 5. 局限与注意事项

1. **es、vi、hi 的标签由 Claude 生成，不能完全重现。** 以本目录中的 `lid_yulun.jsonl` 为准（和 shaoyu 的马来语相同）。这三组的核查也由 Claude 完成，不是独立核查。
2. **专有名词标 `UNKNOWN` 使相邻位置无效。** hi、es、vi 的 UNKNOWN subword（642–819）比文字规则的组（64–194）多很多，切换但 duration 无效的也更多。这是共用提示词"无法可靠判断的专名标 UNKNOWN"的代价，和 shaoyu 的马来语相同。
3. **同一个名字在不同语言对中可能标法不同。** 规则按"相对于这一对语言的书写形式"判断。例如 `Kamala` 在 es、vi 中是 `UNKNOWN`，在 hi 中是印地语名字，标 `hi`。
4. **地名的界线不完全一致。** 例如 es_en 中 `Washington`、`Pennsylvania` 是 `en`，而 `Michigan`、`Tennessee` 是 `UNKNOWN`。这类只有十几个词。
5. **两种标注方法的约定不同。** 文字规则的组把拉丁字母专有名词一律标 `en`（和 shaoyu 相同）；Claude 标注的组按 3.3 节的规则判断。跨方法比较时要注意。
6. **mBERT 词表没有弯引号和破折号。** `’` `“` `”` `‘` `–` `—` 都被切成 `[UNK]`，例如 `It’s` 被切成 `It [UNK] s`（直引号 `It's` 没有问题）。这是各组 `[UNK]` 的主要来源。其他成员的英语文本应该也有同样的问题。
7. **duration 按 subword 计数，片段长度受 tokenizer 影响。** 每个母语词平均的 subword 数：阿拉伯语 2.09、印地语 1.62、日语 1.48、西班牙语 1.29、越南语 1.10、中文 1.00（mBERT 把每个汉字切成一个 token）。`honestly` 一个词被切成 3 个 subword，插入一个英语词就算 Medium。所以 Large 占比在 ar、zh、ja 达到 49%–57%，在 vi 只有 37%；各组之间的差异有一部分来自 tokenizer。课程规格写的是"1–2 tokens"，按 subword 计数符合字面要求，本次按团队规则不改，只记录。
8. **hi_en 的切换率（14.6%）和 Small 占比（44%）明显高于其他组。** 拉丁字母印地语常在印地语句子中插入单个英语词（`match`、`plan`、`team`、`update`），每次插入都是两次切换和一个 Small 片段。这是数据本身的特点。
9. **标点计入片段长度。** 按 `inherit_previous`，句尾标点继承前一个语言并计入长度。例如 `you know?` 的新片段是 3 个 subword，算 Medium；不计 `?` 则是 Small。
10. **片假名外来语标为 `ja`。** 例如 `コンピューター` 是英语借词，但按文字标为 `ja`。已知局限，不是错误。
11. **中文文件中的粤语字标为 `zh`**（约 1.2% 的 record）；`哋`、`咗`、`喺` 是 `[UNK]`，数量很少。
12. **其他文字标为 `UNKNOWN`。** 日语、中文文件中有少量希腊字母；印地语文件中有少量泰卢固文。含 nukta 的天城文词（`खिलाड़ी`、`बढ़`）有时被 mBERT 整个切成 `[UNK]`。
13. **日语中的全角英文字母被整段切成 `[UNK]`**（`ＥＭＡは`），数量很少。
14. **中文、日语没有空格。** 一长串汉字是一个 LID 片段；分词由 tokenizer 完成，不影响标注。
15. **逐条目处理会丢失条目之间的切换。** 和 shaoyu、yufan 相同，见 shaoyu 的 DECISIONS.md 第 4 节。

## 6. 给团队的改进建议（本次未采用）

本次交付的数据**没有使用**这些修改。

| 建议 | 影响 |
|---|---|
| tokenize 前把弯引号、破折号换成 ASCII 形式，或改用词表包含这些字符的 tokenizer | 消除第 5 节第 6 项中的大部分 `[UNK]` |
| duration 按词计数（只数不以 `##` 开头的 subword） | 减少 tokenizer 对 duration 分布的影响，更接近课程对 Small/Medium/Large 的语言学定义；但中文、日语每个字是一个 token，需要另外分词才能按词计数 |
| NEUTRAL token 继承语言但不计入长度 | 解决第 5 节第 9 项 |
| 拉丁字母语言对统一用逐词标注（Claude 或其他上下文模型），不用整句检测器 | Lingua 在附加语切换上的错误集中在切换点（见 3.3） |
| 团队统一专有名词规则 | 目前文字规则组标 `en`、提示词组标 `UNKNOWN`，跨组比较 duration 有效位置时会有偏差 |
