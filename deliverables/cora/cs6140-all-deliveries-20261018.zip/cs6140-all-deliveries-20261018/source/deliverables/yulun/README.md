# Update 1 数据交付：阿拉伯语、印地语、中文、日语、西班牙语、越南语 × 英语

作者：yulun。分支 `data/yulun`，共 6 个语言对：`ar_en`、`hi_en`、`zh_en`、`ja_en`、`es_en`、`vi_en`。

> 当前进度：6 组都已完成，通过 `pipeline.py validate`。每组 20 条 record 已由 Claude 辅助核查（`reviewed`），其余为 `unreviewed`。

全部结果由未修改的共用代码（`update1_data_standard/`，`main` 提交 `367d6ec`）生成，处理设置与团队一致：mBERT（tokenizer_sha256 `78b44c32…`）、逐条目处理、`inherit_previous`、`observed`、`--allow-unreviewed`，每组 500 条 record。做法和理由见 [DECISIONS.md](DECISIONS.md)。

## 1. Baseline 需要的文件

| 文件 | 内容 |
|---|---|
| `<pair>/tokenized/labeled_tokens_yulun.jsonl` | 正式的带标签数据 |
| `<pair>/cs_type_yulun.jsonl` | `sequence_id` → `cs_type`，只用于按切换类型计算 Macro-Average，**不作为模型输入** |
| `<pair>/annotation/pilot_record_ids_yulun.txt` | 20 条核查过的 record，划分时必须固定进 train |

`<pair>` 为 `ar_en`、`hi_en`、`zh_en`、`ja_en`、`es_en`、`vi_en`。

划分命令（在 `update1_data_standard/` 中运行）。先把 6 个 `pilot_record_ids_yulun.txt` 合并成 `all_pilot_record_ids.txt`：

```bash
python pipeline.py split --inputs ../deliverables/yulun/ar_en/tokenized/labeled_tokens_yulun.jsonl ../deliverables/yulun/hi_en/tokenized/labeled_tokens_yulun.jsonl ../deliverables/yulun/zh_en/tokenized/labeled_tokens_yulun.jsonl ../deliverables/yulun/ja_en/tokenized/labeled_tokens_yulun.jsonl ../deliverables/yulun/es_en/tokenized/labeled_tokens_yulun.jsonl ../deliverables/yulun/vi_en/tokenized/labeled_tokens_yulun.jsonl --seed 6140 --train-records all_pilot_record_ids.txt --out combined
```

我测试过这条命令：train / validation / test 为 7,918 / 912 / 900 个序列，没有 record 跨越集合，120 条核查 record 都在 train。ar、zh、ja 和 shaoyu 的 `ko_en` 一起划分也没有报错（tokenizer 和标签规则一致）。

## 2. 文件结构

```text
deliverables/yulun/
  README.md                本文件
  DECISIONS.md             做法、理由、已知问题、建议
  scripts/
    lid_script.py          文字系统规则（shaoyu 版本的扩展）
    test_lid_script.py     lid_script.py 的测试
    lid_claude.py          Claude 逐词标注：切词、组装（--script-native 用于印地语）
    lid_claude_instructions.md  给 Claude 的标注规则（LID_PROMPT.md v1.0 的逐词版本）
    lid_claude_harmonize.py     专有名词和借词的统一步骤
    lid_lingua.py          Lingua 试跑用（结果未采用，见 DECISIONS.md 3.3）
    sample_records.py      抽样（和 shaoyu 的相同）
    make_cs_type_map.py    生成 cs_type 对照表（和 shaoyu 的相同）
    build_item_lid.py      加入核查结果（改自 shaoyu 的同名脚本）
  <pair>/
    cs_type_yulun.jsonl
    extraction/            texts、lid.template、extract_issues、extract_manifest（含抽样信息）、sampled_record_ids
    annotation/            lid、review.csv、pilot_record_ids、lid_manifest、build_manifest
                           （es、vi、hi 另有 harmonize_changes、harmonize_manifest）
    tokenized/             labeled_tokens、token_issues、stats、manifest
```

所有结果文件名都加 `_yulun`。脚本、共用代码和 tokenizer 不加。

## 3. 数据概况

| 语言对 | 方法 | 序列 | 有效位置 | 切换 | 切换率 | Small / Medium / Large | 切换但 duration 无效 | UNKNOWN subword |
|---|---|---:|---:|---:|---:|---|---:|---:|
| ar_en | 文字规则 | 1,594 | 40,784 | 1,936 | 4.7% | 351 / 605 / 935 | 45 | 64 |
| zh_en | 文字规则 | 1,747 | 54,032 | 2,402 | 4.4% | 379 / 668 / 1,283 | 72 | 163 |
| ja_en | 文字规则 | 1,662 | 52,918 | 2,300 | 4.3% | 374 / 567 / 1,254 | 105 | 194 |
| hi_en | 混合 | 1,571 | 42,575 | 6,198 | 14.6% | 2,661 / 2,031 / 1,325 | 181 | 676 |
| es_en | Claude | 1,561 | 37,355 | 2,319 | 6.2% | 417 / 748 / 1,016 | 138 | 642 |
| vi_en | Claude | 1,595 | 39,495 | 2,701 | 6.8% | 640 / 935 / 932 | 194 | 819 |

每组 500 条 record。按切换类型的序列数和 UNKNOWN 的来源见 DECISIONS.md 第 4 节。

## 4. 标注方法与核查

| 语言对 | 方法 |
|---|---|
| ar_en、zh_en、ja_en | `lid_script.py` 按 Unicode 文字系统逐字符标注，和 shaoyu 处理粤语、韩语、俄语的方法相同；只增加了阿拉伯文、天城文、假名的文字范围 |
| es_en、vi_en | `lid_claude.py`：Claude 逐词标注，每个词只回传一个语言代码，程序按原文位置组回 segments，一定逐字还原原文；再统一专有名词和借词 |
| hi_en | 天城文用文字规则，拉丁字母词由 Claude 标注（印地语有一半以上用拉丁字母书写） |

| 字符 | 文字规则的组 | Claude 标注的组 |
|---|---|---|
| 母语词 | 母语代码 | 母语代码（按上下文） |
| 英语词 | `en` | `en`（按上下文，包括附加语 `you know?`、`right?`） |
| 专有名词 | 拉丁字母一律 `en` | 按书写形式：英语形式 `en`、母语形式母语、拼法相同或第三种语言 `UNKNOWN` |
| 数字、标点、符号（包括 `،` `؟` `।`） | `NEUTRAL` | `NEUTRAL` |

拉丁字母的组先试过 Lingua（yufan 的工具），附加语切换的错误集中在切换点，所以改用 Claude，见 DECISIONS.md 3.3。

核查：每组 20 条 record（共 416 个条目），由 Claude 辅助核查，6 组都没有需要修正的地方。见 DECISIONS.md 3.5。

## 5. 使用注意事项

1. **核查是模型辅助的。** 报告中不能称为人工核查。es、vi、hi 的标注和核查都由 Claude 完成，核查不是独立的。**其余条目是伪标签**（`unreviewed`）。在这些数据上得到的 F1，不能称为对人工真值的准确率。
2. **es、vi、hi 的标签不能完全重现**，以本目录中的 `lid_yulun.jsonl` 为准。
3. **两种方法对专有名词的约定不同**（见上表）。hi、es、vi 的专有名词常标 `UNKNOWN`，相邻位置的 switch 和 duration 无效。
4. **中文用 `zh`**，指 SwitchLingua 的 Chinese 文件；约 1.2% 的 record 含粤语字，也标为 `zh`。
5. **弯引号 `’` 和破折号是 `[UNK]`。** mBERT 词表没有这些字符，它们是各组 `[UNK]` 的主要来源。
6. **duration 分布受 tokenizer 影响。** Large 占比从 vi 的 37% 到 ja 的 57%（hi 为 22%），一部分原因是 mBERT 切分各语言的细碎程度不同。
7. **hi_en 的切换率（14.6%）明显较高**，因为拉丁字母印地语常插入单个英语词。
8. 其他问题见 DECISIONS.md 第 5 节。

## 6. 如何重现结果

原始 CSV 不在仓库中（数据集许可不允许再分发）。在 `update1_data_standard/` 中运行。

**文字规则的组**（以阿拉伯语为例；中文、日语把 `Arabic_eng.csv` / `ar,en` / `ar_en` 换成 `Chinese_eng.csv` / `zh,en` / `zh_en`、`Japanese_eng.csv` / `ja,en` / `ja_en`）：

```bash
python pipeline.py extract --input "<路径>/Arabic_eng.csv" --languages ar,en --out data/ar_en/extraction_full
python ../deliverables/yulun/scripts/sample_records.py --extraction data/ar_en/extraction_full --out data/ar_en/extraction
python ../deliverables/yulun/scripts/lid_script.py --texts data/ar_en/extraction/texts.jsonl --out data/ar_en/annotation
```

**Claude 标注的组**（以西班牙语为例；越南语同理；印地语在 `prepare` 和 `assemble` 都加 `--script-native`，输出目录为 `annotation_v2`）：

```bash
python pipeline.py extract --input "<路径>/Spanish_eng.csv" --languages es,en --out data/es_en/extraction_full
python ../deliverables/yulun/scripts/sample_records.py --extraction data/es_en/extraction_full --out data/es_en/extraction
python ../deliverables/yulun/scripts/lid_claude.py prepare --texts data/es_en/extraction/texts.jsonl --out data/es_en/claude_work
# 按 lid_claude_instructions.md 为每个 batch_NNN.input.jsonl 写出 batch_NNN.labels.jsonl
python ../deliverables/yulun/scripts/lid_claude_harmonize.py collect --work data/es_en/claude_work --out data/es_en/harmonize_candidates.jsonl
# 按同一规则为每个候选词写出 harmonize_decisions.jsonl
python ../deliverables/yulun/scripts/lid_claude_harmonize.py apply --work data/es_en/claude_work --candidates data/es_en/harmonize_candidates.jsonl --decisions data/es_en/harmonize_decisions.jsonl --out data/es_en/claude_work_v2
python ../deliverables/yulun/scripts/lid_claude.py assemble --texts data/es_en/extraction/texts.jsonl --work data/es_en/claude_work_v2 --out data/es_en/annotation
```

模型标注每次可能略有不同，所以这三组以本目录中的 `lid_yulun.jsonl` 为准。

**核查和 tokenize**（6 组都完成后）：把各组的 `annotation/pilot_record_ids_yulun.txt` 复制为 `data/<pair>/pilot_record_ids.txt`，然后：

```bash
python ../deliverables/yulun/scripts/build_item_lid.py
python pipeline.py tokenize --texts data/ar_en/annotation_final/texts.jsonl --lid data/ar_en/annotation_final/lid.jsonl --tokenizer-dir assets/chosen_tokenizer --neutral-policy inherit_previous --end-policy observed --allow-unreviewed --out data/ar_en/tokenized_final
python pipeline.py validate --input data/ar_en/tokenized_final/labeled_tokens.jsonl
```

测试（在仓库根目录运行）：

```bash
python -m unittest discover -s deliverables/yulun/scripts -v
```
