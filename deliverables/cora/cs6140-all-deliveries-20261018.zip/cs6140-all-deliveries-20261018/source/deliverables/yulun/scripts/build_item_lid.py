"""Build the final item-level LID for yulun's pairs (run from update1_data_standard/).

Adapted from shaoyu's build_item_lid.py; the review logic and output format are the same.
Inputs per pair, all under data/<pair>/:
- SOURCES[pair][0]/texts.jsonl  item-level texts (unchanged pipeline.py extract + sampling script)
- SOURCES[pair][1]/lid.jsonl    lid_script.py or lid_claude.py output
- pilot_record_ids.txt          20 reviewed records:
                                random.Random(f'6140:{pair}:pilot').sample(sorted(sampled record_ids), 20)
The items of the 20 pilot records get the review fixes in FIXES and review_status=reviewed.
Output: data/<pair>/annotation_final/{texts.jsonl, lid.jsonl, review.csv, build_manifest.json}
Usage: python build_item_lid.py [pair ...]   (default: every pair in SOURCES)
"""
import csv
import datetime
import sys
from pathlib import Path

sys.path.insert(0, '.')
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, validate_lid, digest  # noqa: E402

REVIEWER = 'claude-opus-5-5 (model-assisted review, delegated by yulun)'
SOURCES = {'ar_en': ('extraction', 'annotation'), 'hi_en': ('extraction', 'annotation_v2'),
           'zh_en': ('extraction', 'annotation'), 'ja_en': ('extraction', 'annotation'),
           'es_en': ('extraction', 'annotation'), 'vi_en': ('extraction', 'annotation')}
# record_id -> [context, phrase, lang, reason]; a fix applies to the item that contains context.
# Empty: the pilot review of all six pairs found no errors in the final labels.
FIXES = {}


def merge(text, labs):
    out = []
    for ch, l in zip(text, labs):
        if out and out[-1]['lang'] == l:
            out[-1]['text'] += ch
        else:
            out.append({'text': ch, 'lang': l})
    return out


def build(d, src, texts, pilot, today):
    lids, review = [], []
    for lid in read_jsonl(d / src / 'lid.jsonl'):
        row = texts[lid['sequence_id']]
        if row['record_id'] in pilot:
            labs = [s['lang'] for s in lid['segments'] for _ in s['text']]
            changed = False
            for ctx, phrase, lang, reason in FIXES.get(row['record_id'], []):
                c = row['text'].find(ctx)
                if c < 0:
                    continue
                p = row['text'].find(phrase, c)
                review.append([lid['sequence_id'], REVIEWER, today, 'reviewed', 'error',
                               f'{phrase} = {labs[p]}', f'{phrase} = {lang}', reason])
                labs[p:p + len(phrase)] = [lang] * len(phrase)
                changed = True
            if changed:
                lid = dict(lid, segments=merge(row['text'], labs),
                           annotation_source=lid['annotation_source'] + '+review-fixes')
            else:
                review.append([lid['sequence_id'], REVIEWER, today, 'reviewed', 'none', '', '', 'no change'])
            lid = dict(lid, review_status='reviewed', reviewer=REVIEWER)
        validate_lid(row, lid)
        lids.append(lid)
    return lids, review


today = datetime.date.today().isoformat()
for pair in sys.argv[1:] or SOURCES:
    ex, src = SOURCES[pair]
    d = Path('data') / pair
    texts = {r['sequence_id']: r for r in read_jsonl(d / ex / 'texts.jsonl')}
    pilot = {s.strip() for s in open(d / 'pilot_record_ids.txt', encoding='utf-8') if s.strip()}
    lids, review = build(d, src, texts, pilot, today)
    if {l['sequence_id'] for l in lids} != set(texts):
        raise ValueError(f'{pair}: LID IDs do not match texts')
    if {texts[l['sequence_id']]['record_id'] for l in lids if l['review_status'] == 'reviewed'} != pilot:
        raise ValueError(f'{pair}: reviewed records differ from pilot_record_ids.txt')
    out = new_dir(d / 'annotation_final')
    write_jsonl(out / 'texts.jsonl', list(texts.values()))
    write_jsonl(out / 'lid.jsonl', lids)
    with open(out / 'review.csv', 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['sequence_id', 'reviewer', 'review_date', 'status', 'issue_type', 'before', 'after', 'reason'])
        w.writerows(review)
    write_json(out / 'build_manifest.json', {'date': today, 'source': src, 'items': len(lids),
               'reviewed_items': sum(l['review_status'] == 'reviewed' for l in lids),
               'review_rows': len(review), 'fixes': sum(r[4] == 'error' for r in review),
               'inputs': {p: digest((d / p).read_bytes()) for p in
                          [f'{ex}/texts.jsonl', f'{src}/lid.jsonl', 'pilot_record_ids.txt']},
               'builder_sha256': digest(Path(__file__).read_bytes())})
    print(pair, 'items', len(lids), 'reviewed items', sum(l['review_status'] == 'reviewed' for l in lids),
          'fixes', sum(r[4] == 'error' for r in review))
