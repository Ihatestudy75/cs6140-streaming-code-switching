"""Word-level LID labeled by Claude, for pairs whose two languages both use Latin script.

Two steps, so the model never rewrites the text:
  prepare   split each item into words and write batch files for the labeler
  assemble  read the labeler's per-word codes and build lid.jsonl from the original text

A word is a run of letters (combining marks included) that may contain internal apostrophes or
hyphens. Only words get a language. Everything else (whitespace, punctuation, symbols, digits) is
NEUTRAL, the same character rule as lid_lingua.py / yufan's annotate_lingua.py. Labels follow the
shared LID_PROMPT.md v1.0: judge whole words in context; proper nouns, loanwords or mixed words
whose language cannot be judged reliably are UNKNOWN.

Codes: n = native language, e = en, u = UNKNOWN.

--script-native (for pairs whose native language also has its own script, e.g. Hindi written in
Devanagari or in Latin letters): characters start from the lid_script.py Unicode-script labels, and
only all-Latin words are sent to the labeler. Native-script text keeps exactly the script-rule
labels; only Latin-letter words get a language from context.
"""
import argparse
import datetime
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lid_script  # noqa: E402
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, validate_lid, digest  # noqa: E402

LETTER = r'(?:[^\W\d_]|[̀-ͯ])'
WORD = re.compile(rf"{LETTER}+(?:['’‐‑-]{LETTER}+)*")
PROMPT_VERSION = 'v1.0'


def is_latin_word(word):
    return all('LATIN' in unicodedata.name(ch, '') for ch in word if ch.isalpha())


def words(text, script_native=False):
    spans = [(m.start(), m.end()) for m in WORD.finditer(text)]
    return [(a, z) for a, z in spans if is_latin_word(text[a:z])] if script_native else spans


def native_of(row):
    return next(c for c in row['languages'] if c != 'en')


def prepare(args):
    rows = read_jsonl(args.texts)
    out = new_dir(args.out)
    index = []
    for b in range(0, len(rows), args.batch_size):
        name = f'batch_{b // args.batch_size + 1:03d}'
        items = []
        for i, row in enumerate(rows[b:b + args.batch_size]):
            item_id = b + i + 1
            index.append({'id': item_id, 'sequence_id': row['sequence_id'], 'batch': name})
            items.append({'id': item_id, 'text': row['text'],
                          'words': [row['text'][a:z] for a, z in words(row['text'], args.script_native)]})
        write_jsonl(out / f'{name}.input.jsonl', items)
    write_jsonl(out / 'index.jsonl', index)
    write_json(out / 'prepare_manifest.json', {'texts': args.texts, 'texts_sha256': digest(Path(args.texts).read_bytes()),
               'items': len(rows), 'batch_size': args.batch_size, 'script_native': args.script_native,
               'batches': (len(rows) + args.batch_size - 1) // args.batch_size,
               'script_sha256': digest(Path(__file__).read_bytes())})
    print(f'{len(rows)} items -> {out}')


def assemble(args):
    rows = read_jsonl(args.texts)
    work = Path(args.work)
    index = {r['sequence_id']: r['id'] for r in read_jsonl(work / 'index.jsonl')}
    codes = {}
    for p in sorted(work.glob('batch_*.labels.jsonl')):
        for r in read_jsonl(p):
            if r['id'] in codes:
                raise ValueError(f'Duplicate labels for id {r["id"]}')
            codes[r['id']] = r['labels'].split()
    lids, counts, problems = [], Counter(), []
    date = datetime.date.today().isoformat()
    for row in rows:
        native = native_of(row)
        lang = {'n': native, 'e': 'en', 'u': 'UNKNOWN'}
        item_id = index[row['sequence_id']]
        spans = words(row['text'], args.script_native)
        labs = codes.get(item_id)
        if labs is None or len(labs) != len(spans) or any(c not in lang for c in labs):
            problems.append(item_id)
            continue
        if args.script_native:
            chars = [s['lang'] for s in lid_script.segments_for(row['text'], native) for _ in s['text']]
        else:
            chars = ['NEUTRAL'] * len(row['text'])
        for (a, z), c in zip(spans, labs):
            chars[a:z] = [lang[c]] * (z - a)
        segs = []
        for ch, lab in zip(row['text'], chars):
            if segs and segs[-1]['lang'] == lab:
                segs[-1]['text'] += ch
            else:
                segs.append({'text': ch, 'lang': lab})
        lid = {'sequence_id': row['sequence_id'], 'text_sha256': row['text_sha256'],
               'annotation_source': f'{args.model}/claude-code/lid_claude.py/prompt-{PROMPT_VERSION}/{date}',
               'review_status': 'unreviewed', 'reviewer': '', 'segments': segs}
        validate_lid(row, lid)
        lids.append(lid)
        for s in segs:
            counts[s['lang']] += len(s['text'].strip())
    if problems:
        raise ValueError(f'{len(problems)} items have missing or misaligned labels, e.g. ids {problems[:20]}')
    out = new_dir(args.out)
    write_jsonl(out / 'texts.jsonl', rows)
    write_jsonl(out / 'lid.jsonl', lids)
    write_json(out / 'lid_manifest.json', {'method': 'claude-word-level-lid', 'model': args.model,
               'interface': 'Claude Code (interactive session, subagents)', 'prompt': f'LID_PROMPT.md {PROMPT_VERSION}, applied per word',
               'script_native': args.script_native,
               'date': date, 'input_texts': args.texts, 'sequences': len(lids),
               'non_space_chars_by_label': dict(counts),
               'labels_sha256': {p.name: digest(p.read_bytes()) for p in sorted(work.glob('batch_*.labels.jsonl'))},
               'script_sha256': digest(Path(__file__).read_bytes())})
    print(f'Labeled {len(lids)} sequences; chars by label {dict(counts)}')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='command', required=True)
    s = sub.add_parser('prepare')
    s.add_argument('--texts', required=True)
    s.add_argument('--batch-size', type=int, default=100)
    s.add_argument('--script-native', action='store_true',
                   help='Label native-script text by lid_script.py; send only all-Latin words to the labeler')
    s.add_argument('--out', required=True)
    s.set_defaults(func=prepare)
    s = sub.add_parser('assemble')
    s.add_argument('--texts', required=True)
    s.add_argument('--work', required=True, help='Directory from prepare, with batch_*.labels.jsonl added')
    s.add_argument('--model', default='claude-opus-5-5')
    s.add_argument('--script-native', action='store_true', help='Must match the prepare step')
    s.add_argument('--out', required=True)
    s.set_defaults(func=assemble)
    args = p.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
