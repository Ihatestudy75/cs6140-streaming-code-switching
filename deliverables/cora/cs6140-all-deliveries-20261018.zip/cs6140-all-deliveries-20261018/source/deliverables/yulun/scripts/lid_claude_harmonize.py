"""Second pass for lid_claude.py: relabel proper nouns and loanwords with one consistent rule.

The first pass is split across several labelers, who may apply rules 4-5 of
lid_claude_instructions.md differently. This pass collects every word that those rules govern and
sends all of them to a single labeler, so each name and loanword gets the same treatment.

  collect  write candidates.jsonl (word, its item text, current code) from a labeled work dir
  apply    copy the work dir with the reviewer's codes applied; record every change

Candidates: words coded u; capitalized words that do not start the item (except "I"); English
insertions inside native context (an e word whose neighbours are both n); and every occurrence of
a lowercase word that received both e and n somewhere, except short function words that are true
homographs in the two languages.
"""
import argparse
import json
import shutil
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'update1_data_standard'))
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, digest  # noqa: E402

HOMOGRAPHS = {'a', 'en', 'me', 'no', 'he', 'era', 'has', 'son', 'sin', 'come', 'tan', 'red', 'fin', 'pan', 'mar', 'dice', 'once', 'e', 'o', 'y', 'i'}


def load(work):
    items = {}
    for p in sorted(work.glob('batch_*.input.jsonl')):
        for r in read_jsonl(p):
            items[r['id']] = dict(r, batch=p.name.split('.')[0])
        for r in read_jsonl(work / p.name.replace('.input.', '.labels.')):
            items[r['id']]['labels'] = r['labels'].split()
    return items


def collect(args):
    items = load(Path(args.work))
    mixed = defaultdict(set)
    for r in items.values():
        for w, c in zip(r['words'], r['labels']):
            if w.islower():
                mixed[w].add(c)
    mixed = {w for w, cs in mixed.items() if {'e', 'n'} <= cs and w not in HOMOGRAPHS}
    rows = []
    for r in items.values():
        w, c = r['words'], r['labels']
        for k in range(len(w)):
            insertion = (c[k] == 'e' and 0 < k < len(w) - 1 and c[k - 1] == 'n' and c[k + 1] == 'n')
            capital = k > 0 and w[k][:1].isupper() and w[k] != 'I'
            if c[k] == 'u' or capital or insertion or w[k] in mixed:
                rows.append({'cid': len(rows) + 1, 'id': r['id'], 'k': k, 'word': w[k],
                             'current': c[k], 'text': r['text']})
    out = Path(args.out)
    if out.exists():
        raise ValueError(f'{out} exists')
    write_jsonl(out, rows)
    print(f'{len(rows)} candidates -> {out}')


def apply(args):
    work = Path(args.work)
    items = load(work)
    decisions = {r['cid']: r['label'] for r in read_jsonl(args.decisions)}
    candidates = read_jsonl(args.candidates)
    if set(decisions) != {c['cid'] for c in candidates} or any(v not in 'neu' for v in decisions.values()):
        raise ValueError('Decisions must cover every candidate exactly, with codes n/e/u')
    changes = []
    for c in candidates:
        r = items[c['id']]
        if r['words'][c['k']] != c['word'] or r['labels'][c['k']] != c['current']:
            raise ValueError(f'Candidate {c["cid"]} does not match the work dir')
        new = decisions[c['cid']]
        if new != c['current']:
            changes.append({'id': c['id'], 'k': c['k'], 'word': c['word'], 'before': c['current'], 'after': new})
            r['labels'][c['k']] = new
    out = new_dir(args.out)
    for p in work.glob('batch_*.input.jsonl'):
        shutil.copy(p, out / p.name)
    for name in ['index.jsonl', 'prepare_manifest.json']:
        shutil.copy(work / name, out / name)
    by_batch = defaultdict(list)
    for r in sorted(items.values(), key=lambda r: r['id']):
        by_batch[r['batch']].append({'id': r['id'], 'labels': ' '.join(r['labels'])})
    for b, rows in by_batch.items():
        write_jsonl(out / f'{b}.labels.jsonl', rows)
    write_jsonl(out / 'harmonize_changes.jsonl', changes)
    write_json(out / 'harmonize_manifest.json', {'source_work': str(work), 'candidates': len(candidates),
               'changes': len(changes), 'candidates_sha256': digest(Path(args.candidates).read_bytes()),
               'decisions_sha256': digest(Path(args.decisions).read_bytes()),
               'script_sha256': digest(Path(__file__).read_bytes())})
    print(f'{len(changes)} of {len(candidates)} candidates changed -> {out}')


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest='command', required=True)
    s = sub.add_parser('collect')
    s.add_argument('--work', required=True)
    s.add_argument('--out', required=True)
    s.set_defaults(func=collect)
    s = sub.add_parser('apply')
    s.add_argument('--work', required=True)
    s.add_argument('--candidates', required=True)
    s.add_argument('--decisions', required=True, help='JSONL of {"cid": n, "label": "n|e|u"}')
    s.add_argument('--out', required=True)
    s.set_defaults(func=apply)
    args = p.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
