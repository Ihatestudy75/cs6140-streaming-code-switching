"""Model-based LID with Lingua, for pairs whose two languages both use Latin script.

Lingua's detect_multiple_languages_of() assigns language spans over the whole item. The
span-to-character conversion is the same as yufan's annotate_lingua.py: whitespace, punctuation,
symbols and standalone numbers -> NEUTRAL (word-internal apostrophes and hyphens stay with the
word); characters outside every detected span -> UNKNOWN. Runs of equal labels become lid.jsonl
segments. Unlike yufan's script, no items are skipped or deduplicated (same as lid_script.py).
Requires lingua-language-detector, which is not in requirements.lock.txt; use a separate venv.
"""
import argparse
import datetime
import importlib.metadata
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

from lingua import Language, LanguageDetectorBuilder

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'update1_data_standard'))
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, validate_lid, digest  # noqa: E402

LINGUA = {'es': Language.SPANISH, 'vi': Language.VIETNAMESE, 'en': Language.ENGLISH}


def segments_for(text, detector, mapping):
    labels = ['UNKNOWN'] * len(text)
    previous_end = 0
    for hit in detector.detect_multiple_languages_of(text):
        start, end = hit.start_index, hit.end_index
        if not previous_end <= start < end <= len(text):
            raise ValueError('Invalid or overlapping detector offsets')
        labels[start:end] = [mapping[hit.language]] * (end - start)
        previous_end = end
    for i, ch in enumerate(text):
        internal = (ch in "'’‐‑-" and 0 < i < len(text) - 1
                    and text[i - 1].isalpha() and text[i + 1].isalpha())
        if ch.isspace() or (unicodedata.category(ch)[0] in 'PS' and not internal):
            labels[i] = 'NEUTRAL'
    for m in re.finditer(r'\b\d+\b', text):
        labels[m.start():m.end()] = ['NEUTRAL'] * len(m.group())
    segs = []
    for ch, lab in zip(text, labels):
        if segs and segs[-1]['lang'] == lab:
            segs[-1]['text'] += ch
        else:
            segs.append({'text': ch, 'lang': lab})
    return segs


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--texts', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    rows = read_jsonl(args.texts)
    codes = rows[0]['languages']
    if any(r['languages'] != codes for r in rows) or 'en' not in codes or any(c not in LINGUA for c in codes):
        raise ValueError(f'Lingua rule needs en plus one of {sorted(set(LINGUA) - {"en"})}: {codes}')
    mapping = {LINGUA[c]: c for c in codes}
    detector = LanguageDetectorBuilder.from_languages(*mapping).build()
    version = importlib.metadata.version('lingua-language-detector')
    date = datetime.date.today().isoformat()
    lids, counts = [], Counter()
    for row in rows:
        segs = segments_for(row['text'], detector, mapping)
        lid = {'sequence_id': row['sequence_id'], 'text_sha256': row['text_sha256'],
               'annotation_source': f'lingua-language-detector/{version}/lid_lingua.py/{date}',
               'review_status': 'unreviewed', 'reviewer': '', 'segments': segs}
        validate_lid(row, lid)
        lids.append(lid)
        for s in segs:
            counts[s['lang']] += len(s['text'].strip())
    out = new_dir(args.out)
    write_jsonl(out / 'texts.jsonl', rows)
    write_jsonl(out / 'lid.jsonl', lids)
    write_json(out / 'lid_manifest.json', {'method': 'lingua-detect-multiple-languages',
               'tool': 'lingua-language-detector', 'version': version,
               'detector_languages': [lang.name for lang in mapping], 'date': date,
               'input_texts': args.texts, 'sequences': len(lids),
               'non_space_chars_by_label': dict(counts),
               'script_sha256': digest(Path(__file__).read_bytes())})
    print(f'Labeled {len(lids)} sequences; chars by label {dict(counts)}')


if __name__ == '__main__':
    main()
