"""Sample original records that contain native-script letters, from an unchanged `pipeline.py extract` output.

Used for hi_en: most Hindi_eng.csv records write Hindi in Latin letters, which the script rule would
label en. Only records with at least one item containing a native-script letter (as defined by
lid_script.NATIVE) are eligible. Sampled records:
random.Random(f'{seed}:{pair}').sample(sorted(eligible_record_ids), n)  (the same form yufan uses
for a screened population). record_id keeps the full-file row number, so it stays traceable to the CSV.
"""
import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lid_script import NATIVE, in_ranges  # noqa: E402
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, digest  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--extraction', required=True, help='Directory written by pipeline.py extract (full file)')
    p.add_argument('--native', required=True, help=f'Native language code, one of {sorted(NATIVE)}')
    p.add_argument('--n', type=int, default=500)
    p.add_argument('--seed', type=int, default=6140)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    src = Path(args.extraction)
    manifest = json.loads((src / 'extract_manifest.json').read_text(encoding='utf-8'))
    pair = manifest['language_pair']
    if manifest.get('limit'):
        raise ValueError('Extraction must cover the full file (no --limit)')
    all_texts = read_jsonl(src / 'texts.jsonl')
    if args.native not in all_texts[0]['languages']:
        raise ValueError(f'{args.native} is not a language of {pair}')
    has_native = lambda text: any(ch.isalpha() and in_ranges(ord(ch), NATIVE[args.native]) for ch in text)
    eligible = sorted({r['record_id'] for r in all_texts if has_native(r['text'])})
    rids = set(random.Random(f'{args.seed}:{pair}').sample(eligible, min(args.n, len(eligible))))
    keep = lambda sid: sid.rsplit(':', 1)[0] in rids or sid in rids
    texts = [r for r in all_texts if r['record_id'] in rids]
    template = [r for r in read_jsonl(src / 'lid.template.jsonl') if keep(r['sequence_id'])]
    issues = [i for i in read_jsonl(src / 'extract_issues.jsonl') if keep(i['id'])]
    out = new_dir(args.out)
    write_jsonl(out / 'texts.jsonl', texts)
    write_jsonl(out / 'lid.template.jsonl', template)
    write_jsonl(out / 'extract_issues.jsonl', issues)
    write_json(out / 'extract_manifest.json', dict(manifest, sample={
        'n': len(rids), 'seed': args.seed,
        'rule': "random.Random(f'{seed}:{pair}').sample(sorted(eligible_record_ids), n)",
        'eligibility': f'record has at least one item containing a {args.native} native-script letter',
        'eligible_records': len(eligible), 'all_records_with_items': len({r['record_id'] for r in all_texts}),
        'records_with_items': len({r['record_id'] for r in texts}), 'items': len(texts),
        'issues': len(issues), 'full_texts_sha256': digest((src / 'texts.jsonl').read_bytes())}))
    write_jsonl(out / 'sampled_record_ids.jsonl', [{'record_id': r} for r in sorted(rids)])
    print(f'{pair}: {len(eligible)} eligible records, {len(rids)} sampled, {len(texts)} items, {len(issues)} issues')


if __name__ == '__main__':
    main()
