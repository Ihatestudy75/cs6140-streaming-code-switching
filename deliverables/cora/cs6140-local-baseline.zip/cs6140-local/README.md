# CS6140 local experiment

先读 [REPORT.md](REPORT.md)。全部产物已运行完成；来源 PR #1，commit 440cbb032b57b010f909ac30d6deb223f7e642dc。无 GitHub 写操作。

复现：`python3 run.py --out runs/v2`。只用 Python 标准库。
