# shaoyu 的 Update 1 数据交付

交付日期：2026-10-15。分支：`data/shaoyu`。语言对：粤语–英语、韩语–英语、俄语–英语、马来语–英语。

**共用代码没有修改。** 所有结果都用 `update1_data_standard/` 的原始代码（`main` 提交 `367d6ec`）生成，设置为 mBERT（tokenizer_sha256 `78b44c32…`）、逐条目处理、`inherit_previous`、`observed`。我写的工具都在本目录的 `scripts/` 中，不影响共用代码。

4 组都通过了 `pipeline.py validate`，可以和其他成员的结果一起运行 `split`。做法和理由见 [DECISIONS.md](DECISIONS.md)。

## 1. 交给 Baseline 的文件

| 文件 | 内容 |
|---|---|
| `<pair>/tokenized/labeled_tokens_shaoyu.jsonl` | 正式的带标签数据 |
| `<pair>/cs_type_shaoyu.jsonl` | `sequence_id` → `cs_type`，用于按切换类型计算 Macro-Average |
| `<pair>/annotation/pilot_record_ids_shaoyu.txt` | 20 条核查过的 record，划分时必须固定进 train |

`<pair>` 为 `yue_en`、`ko_en`、`ru_en`、`ms_en`。

划分命令（在 `update1_data_standard/` 中运行）。先把 4 个 `pilot_record_ids_shaoyu.txt` 合并成 `all_pilot_record_ids.txt`：

```bash
python pipeline.py split --inputs ../deliverables/shaoyu/yue_en/tokenized/labeled_tokens_shaoyu.jsonl ../deliverables/shaoyu/ko_en/tokenized/labeled_tokens_shaoyu.jsonl ../deliverables/shaoyu/ru_en/tokenized/labeled_tokens_shaoyu.jsonl ../deliverables/shaoyu/ms_en/tokenized/labeled_tokens_shaoyu.jsonl --seed 6140 --train-records all_pilot_record_ids.txt --out combined
```

我测试过这条命令：train / validation / test 为 5,876 / 683 / 662 个序列，没有 record 跨越集合，80 条核查 record 都在 train。`loader.py` 能正常读取结果。

**`cs_type` 的用法：** `loader.py` 的 `provenance` 中有 `sequence_id`。用它查 `cs_type_shaoyu.jsonl`，就能按切换类型汇总分数。**不要**把 `cs_type` 作为模型输入。

## 2. 目录结构

```text
deliverables/shaoyu/
  README.md                本文件
  DECISIONS.md             做法、理由、已知问题、对共用代码的建议
  scripts/                 我的工具（不修改共用代码）
  <pair>/
    cs_type_shaoyu.jsonl
    extraction/            texts、lid.template、extract_issues、extract_manifest（含抽样信息）
    annotation/            lid、review.csv、pilot_record_ids、lid_manifest、build_manifest
    tokenized/             labeled_tokens、token_issues、stats、manifest
```

所有结果文件名都加了 `_shaoyu`。

## 3. 统计

| 语言对 | record | 序列 | 有效位置 | 切换 | 切换率 | Small / Medium / Large | 切换但 duration 无效 | UNKNOWN subword |
|---|---|---|---|---|---|---|---|---|
| yue_en | 499 | 2,560 | 54,848 | 3,030 | 5.5% | 732 / 846 / 1,130 | 322 | 1,950 |
| ko_en | 500 | 1,529 | 41,863 | 2,237 | 5.3% | 487 / 592 / 1,084 | 74 | 172 |
| ru_en | 500 | 1,564 | 40,585 | 2,082 | 5.1% | 361 / 696 / 966 | 59 | 109 |
| ms_en | 500 | 1,568 | 36,634 | 2,929 | 8.0% | 915 / 878 / 953 | 183 | 1,512 |

按切换类型的切换率：

| 语言对 | Intersentential | Intrasentential | Extra-sentential / Tag |
|---|---|---|---|
| yue_en | 4.9% | 6.0% | 5.7% |
| ko_en | 4.1% | 6.1% | 6.0% |
| ru_en | 3.4% | 5.8% | 6.3% |
| ms_en | 4.8% | 9.8% | 9.7% |

## 4. LID 方法

| | 粤语、韩语、俄语 | 马来语 |
|---|---|---|
| 方法 | `scripts/lid_script.py`：按 Unicode 文字系统标注 | `scripts/lid_llm.py`：DeepSeek `deepseek-flash`，思考模式，共用提示词 v1.0 |
| 专有名词 | 拉丁字母写的都标 `en` | 由模型按上下文判断，无法判断的标 `UNKNOWN`（v1.0 规则） |
| 核查修正 | 粤语 1 处，韩语、俄语 0 处 | 0 处 |

## 5. 使用前要知道的

1. **核查是模型辅助的。** 每组 20 条 record 由 Claude 核查。报告中不能称为独立的人工核查。
2. **其余条目是伪标签**（`unreviewed`）。在这些数据上得到的 F1，不能称为对人工真值的准确率。
3. **粤语 `[UNK]` 问题。** mBERT 词表缺少 `哋`、`啲`、`咗` 等常用粤语字（55 个字，1,671 次），它们的语言标为 `UNKNOWN`。这可以作为检查表第 5 项（Next Steps）的例子。
4. **逐条目处理会丢失句间切换。** 2,560 个粤语序列中有 903 个没有切换。改为按 record 拼接后，切换数会多 31%–41%。见 DECISIONS.md 第 4 节。
5. **马来语专有名词常标为 `UNKNOWN`**（v1.0 规则），旁边的位置无效。
6. 其他问题见 DECISIONS.md 第 3 节。

## 6. 复现

原始 CSV 不在仓库中。在 `update1_data_standard/` 中运行（以韩语为例）：

```bash
python pipeline.py extract --input "<路径>/Korean_eng.csv" --languages ko,en --out data/ko_en/extraction_item_full
```

```bash
python ../deliverables/shaoyu/scripts/sample_records.py --extraction data/ko_en/extraction_item_full --out data/ko_en/extraction_item
```

```bash
python ../deliverables/shaoyu/scripts/lid_script.py --texts data/ko_en/extraction_item/texts.jsonl --out data/ko_en/annotation_item
```

然后用 `scripts/build_item_lid.py` 加入核查结果，再运行：

```bash
python pipeline.py tokenize --texts data/ko_en/annotation_item_final/texts.jsonl --lid data/ko_en/annotation_item_final/lid.jsonl --tokenizer-dir assets/chosen_tokenizer --neutral-policy inherit_previous --end-policy observed --allow-unreviewed --out data/ko_en/tokenized_item
```

马来语用下面的命令代替 `lid_script.py`。它需要 DeepSeek API key，key 放在仓库外的文件中：

```bash
python ../deliverables/shaoyu/scripts/lid_llm.py --texts data/ms_en/extraction_item/texts.jsonl --model deepseek-flash --key-file "<key 文件路径>" --thinking enabled --reasoning-effort high --prompt-version v1.0 --workers 16 --out data/ms_en/annotation_item_llm_v10
```

大模型输出每次可能略有不同，所以马来语以本目录中的 `lid_shaoyu.jsonl` 为准。
