"""Write sequence_id -> cs_type from the original CSV (the shared pipeline drops this column).

Join it to labeled_tokens or to loader provenance on sequence_id. It is evaluation metadata only:
never give it to the predictor as input.
"""
import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'update1_data_standard'))
from pipeline import read_jsonl, write_jsonl, digest  # noqa: E402

csv.field_size_limit(10**9)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv', required=True)
    p.add_argument('--texts', required=True, help='texts.jsonl from pipeline.py extract')
    p.add_argument('--out', required=True)
    args = p.parse_args()
    rows = read_jsonl(args.texts)
    if digest(Path(args.csv).read_bytes())[:12] != rows[0]['record_id'].split(':')[1]:
        raise ValueError('CSV checksum does not match record_id')
    wanted = {r['source_row'] for r in rows}
    cs_type = {}
    with open(args.csv, encoding='utf-8-sig', newline='') as f:
        for n, row in enumerate(csv.DictReader(f), 1):
            if n in wanted:
                cs_type[n] = row['cs_type']
    write_jsonl(args.out, [{'sequence_id': r['sequence_id'], 'record_id': r['record_id'],
                            'language_pair': r['language_pair'], 'cs_type': cs_type[r['source_row']]}
                           for r in rows])
    print(f'{len(rows)} sequences -> {args.out}')


if __name__ == '__main__':
    main()
