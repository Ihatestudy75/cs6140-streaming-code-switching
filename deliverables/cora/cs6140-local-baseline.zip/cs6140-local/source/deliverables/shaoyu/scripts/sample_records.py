"""Keep a random sample of original records from an unchanged `pipeline.py extract` output.

The shared pipeline is not modified. Run `pipeline.py extract` on the full CSV first, then this
script. Sampled CSV rows: random.Random(f'{seed}:{pair}').sample(range(1, total+1), n).
record_id keeps the full-file row number, so it stays traceable to the CSV.
"""
import argparse
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'update1_data_standard'))
from pipeline import read_jsonl, write_jsonl, write_json, new_dir, digest  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--extraction', required=True, help='Directory written by pipeline.py extract (full file)')
    p.add_argument('--n', type=int, default=500)
    p.add_argument('--seed', type=int, default=6140)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    src = Path(args.extraction)
    manifest = json.loads((src / 'extract_manifest.json').read_text(encoding='utf-8'))
    pair, total = manifest['language_pair'], manifest['input_records']
    if manifest.get('limit'):
        raise ValueError('Extraction must cover the full file (no --limit)')
    rows = sorted(random.Random(f'{args.seed}:{pair}').sample(range(1, total + 1), min(args.n, total)))
    rids = {f'{pair}:{manifest["source_sha256"][:12]}:{r:06d}' for r in rows}
    keep = lambda sid: sid.rsplit(':', 1)[0] in rids or sid in rids
    texts = [r for r in read_jsonl(src / 'texts.jsonl') if r['record_id'] in rids]
    template = [r for r in read_jsonl(src / 'lid.template.jsonl') if keep(r['sequence_id'])]
    issues = [i for i in read_jsonl(src / 'extract_issues.jsonl') if keep(i['id'])]
    out = new_dir(args.out)
    write_jsonl(out / 'texts.jsonl', texts)
    write_jsonl(out / 'lid.template.jsonl', template)
    write_jsonl(out / 'extract_issues.jsonl', issues)
    write_json(out / 'extract_manifest.json', dict(manifest, sample={
        'n': len(rids), 'seed': args.seed, 'rule': "random.Random(f'{seed}:{pair}').sample(range(1, total+1), n)",
        'records_with_items': len({r['record_id'] for r in texts}), 'items': len(texts),
        'issues': len(issues), 'full_texts_sha256': digest((src / 'texts.jsonl').read_bytes())}))
    write_jsonl(out / 'sampled_record_ids.jsonl', [{'record_id': r} for r in sorted(rids)])
    print(f'{pair}: {len(rids)} records sampled, {len({r["record_id"] for r in texts})} with items, '
          f'{len(texts)} items, {len(issues)} issues')


if __name__ == '__main__':
    main()
